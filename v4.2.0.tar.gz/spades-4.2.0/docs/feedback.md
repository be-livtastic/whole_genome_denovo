# Feedback and bug reports

Your comments, bug reports, and suggestions are very welcomed. They will help us to further improve SPAdes. If you have any troubles running SPAdes, please send us `params.txt` and `spades.log` from the output folder.

You can leave your comments and bug reports at [our GitHub repository tracker](https://github.com/ablab/spades/issues).
